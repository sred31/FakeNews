Guys... this app is the most important thing we will ever do!!! We must work with the fury of a thousand warriors if we want to succeed!
