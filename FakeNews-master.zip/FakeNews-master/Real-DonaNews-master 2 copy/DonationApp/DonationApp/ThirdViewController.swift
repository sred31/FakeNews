//
//  SecondViewController.swift
//  DonationApp
//
//  Created by Michael Bardos on 1/28/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    
    @IBOutlet weak var sideMenuConstraint: NSLayoutConstraint!
    var sideMenuOpen = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(toggleSideMenu), name: NSNotification.Name("ToggleSideMenu"), object: nil)
    }
    
    @objc func toggleSideMenu(){
        if sideMenuOpen {
            sideMenuConstraint.constant = -240
        }else{
            sideMenuConstraint.constant = 0
        }
        sideMenuOpen = !sideMenuOpen
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
    }
    
}

