//
//  LoginViewController.swift
//  DonationApp
//
//  Created by Michael Bardos on 2/7/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate{

    //MARK: Properties
    @IBOutlet weak var uNameTxtFld: UITextField!
    @IBOutlet weak var pWordTxtFld: UITextField!
    
    
    
    
    override func viewDidLoad() {
        //Handle all text fields' user input through delegate callbacks
        uNameTxtFld.delegate = self
        pWordTxtFld.delegate = self
        
        super.viewDidLoad()

        
    }
    
    //MARK: UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        //Hide the keyboard
        textField.resignFirstResponder()
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
