//
//  Disaster.swift
//  DonationApp
//
//  Created by Michael Bardos on 1/30/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit

class Disaster{
    
    //MARK: Properties
    
    var name: String
    var photo: UIImage
    var description: String
    var URLs: String
    
    //MARK: Initialization
    
    init?(name: String, photo: UIImage, description: String, URLs: String){
        
        //Initialization should fail if there is no name or if the rating is negative.
        if name.isEmpty || description.isEmpty || URLs.isEmpty {
            return nil
        }
        
        //Initialize stored properties
        self.name = name
        self.photo = photo
        self.description = description
        self.URLs = URLs
    }
}
