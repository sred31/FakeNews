//
//  SignUpViewController.swift
//  DonationApp
//
//  Created by Michael Bardos on 2/7/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController, UITextFieldDelegate {
    
    //MARK: Properties
    @IBOutlet weak var eAddrTxtFld: UITextField!
    @IBOutlet weak var uNameTxtFld: UITextField!
    @IBOutlet weak var ConfirmUNameTxtFld: UITextField!
    @IBOutlet weak var pWordTxtFld: UITextField!
    @IBOutlet weak var ConfirmPWordTxtFld: UITextField!
    

    override func viewDidLoad() {
        

        eAddrTxtFld.delegate = self
        uNameTxtFld.delegate = self
        ConfirmUNameTxtFld.delegate = self
        pWordTxtFld.delegate = self
        ConfirmUNameTxtFld.delegate = self
        
        super.viewDidLoad()
        
    }
    
    //MARK: UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        //Hide the keyboard
        textField.resignFirstResponder()
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
