//
//  ProfileVC.swift
//  DonaNewsNS
//
//  Created by Sahil Reddy on 4/8/19.
//  Copyright © 2019 Sahil Reddy. All rights reserved.
//

import UIKit

class ProfileVC: UIViewController {
    override func viewDidLoad() {
        
        navigationItem.title = "Profile"
        navigationController?.navigationBar.isTranslucent = false
        
        view?.backgroundColor = .blue
    }
    
}

