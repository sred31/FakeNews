//
//  donaProgressVC.swift
//  DonaNewsNS
//
//  Created by Sahil Reddy on 4/16/19.
//  Copyright © 2019 Sahil Reddy. All rights reserved.
//

import UIKit

class donaProgressVC: UIViewController {
    override func viewDidLoad() {
        
        navigationItem.title = "Donation Progress"
        navigationController?.navigationBar.isTranslucent = false
        
        view?.backgroundColor = .blue
    }
    
}
