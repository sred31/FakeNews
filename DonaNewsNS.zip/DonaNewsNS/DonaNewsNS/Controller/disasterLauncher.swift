//
//  disasterLauncher.swift
//  DonaNewsNS
//
//  Created by Sahil Reddy on 4/9/19.
//  Copyright © 2019 Sahil Reddy. All rights reserved.
//

import UIKit
class disasterPic: UIImageView{
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black
        
       // let imageView = UIImageView()
        self.image = UIImage(named: "wildfire")
        self.contentMode = .scaleAspectFill
        self.clipsToBounds = true
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.black.cgColor
        
    
        
    
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class disasterLauncher: UIViewController{
    
    
    func showDisaster(){
        
        print("Show Disaster")
        if let keyWindow = UIApplication.shared.keyWindow {
            let view = UIView(frame: keyWindow.frame)
            view.backgroundColor = UIColor.white
            navigationItem.title = "Disaster"
            navigationController?.navigationBar.isTranslucent = false
            view.frame = CGRect(x: keyWindow.frame.width - 10, y: keyWindow.frame.height - 10, width: 10, height: 10)
            
            //16 x 9 is the aspect ratio of all HD videos
            let height = keyWindow.frame.width * 9 / 16
            let disasterPicFrame = CGRect(x: 16, y: 80, width: keyWindow.frame.width-32, height: height)
            let disasterView = disasterPic(frame: disasterPicFrame)
            
            
            //textfield
            let disTextField = UITextField(frame: CGRect(x: 16, y: height + 96, width: keyWindow.frame.width-32 , height: height - 48))
            disTextField.text = "Millions of Americans displaced by wildfires this week"
            disTextField.font = UIFont.systemFont(ofSize: 15)
            disTextField.borderStyle = UITextField.BorderStyle.roundedRect
            disTextField.autocorrectionType = UITextAutocorrectionType.no
            disTextField.keyboardType = UIKeyboardType.default
            disTextField.returnKeyType = UIReturnKeyType.done
            disTextField.clearButtonMode = UITextField.ViewMode.whileEditing
            disTextField.contentVerticalAlignment = UIControl.ContentVerticalAlignment.center
            disTextField.backgroundColor = UIColor.init(red: 88/255, green: 179/255, blue: 21/255, alpha: 1)
            disTextField.layer.borderWidth = 1
            disTextField.layer.borderColor = UIColor.black.cgColor
            
            //disTextField.delegate = self
            //end of textfield
            
            //button
            let donateButton = UIButton(frame: CGRect(x:296, y: height + 296, width:100, height: 50))
            donateButton.backgroundColor = .red
            donateButton.setTitle("Donate", for: .normal)
            donateButton.layer.cornerRadius = 5
            donateButton.clipsToBounds = true
            donateButton.addTarget(self, action: #selector(paymentPage), for: .touchUpInside)
            
            //end of button
            view.addSubview(disasterView)
            view.addSubview(disTextField)
            view.addSubview(donateButton)

            keyWindow.addSubview(view)
            //keyWindow.addConstraintsWithFormat("V:|16-[v0]-16-[v1]", views: view, disTextField)
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
                
                view.frame = keyWindow.frame
            }) { (_) in
                UIApplication.shared.setStatusBarHidden(true, with: .fade)
            }
        }
    
    }
    @objc func paymentPage(sender : UIButton){
        /*let alert = UIAlertController(title: "Clicked", message: "You have clicked on the button", preferredStyle: .alert)
        
        self.present(alert, animated: true, completion: nil)*/
        print("Donation Button sent!!")
    }
}
