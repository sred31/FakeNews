//
//  ProfileVC.swift
//  DonationApp
//
//  Created by Sahil Reddy on 2/5/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit
import Firebase

class ProfileVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var profilePic: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        profilePic.layer.borderWidth = 1
        profilePic.layer.masksToBounds = false
        profilePic.layer.borderColor = UIColor.black.cgColor
        profilePic.layer.cornerRadius = profilePic.frame.height/2
        profilePic.clipsToBounds = true
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    //MARK: Actions
    
    @IBAction func SignOut(_ sender: UIButton) {
        var SOError = false
        
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print("Error signing out")
            SOError = true
        }
        
        if SOError == false {
            let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let entryViewController = storyboard.instantiateViewController(withIdentifier: "EntryVC")
            self.present(entryViewController, animated: true, completion: nil)
        }
    }
    
    
    @IBAction func selectImageFromPhotoLibrary(_ sender: UITapGestureRecognizer) {
        //UIImagePickercontroller is a view controller that lets a user ipck media from their photo library
        
        let imagePickerController = UIImagePickerController()
        
        //Only allow photos to be picked, not taken.
        imagePickerController.sourceType = .photoLibrary
        
        //MAke sure ViewController is notified when the user picks an image.
        imagePickerController.delegate = self
        present(imagePickerController, animated: true, completion: nil)
    }
    
    //MARK: UIImagePickerControllerDelegate
    
    func imagePickerControllerDidCancel(_ _picker: UIImagePickerController){
        //Dismiss the picker if the user canceled
        
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        //The info dictionary may contain multiple represenations of the image. You want to use the original.
        
        guard let selectedImage = info[.originalImage] as? UIImage else{
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        
        //Set photoImageView to display the selected image.
        profilePic.image = selectedImage
        
        //Dismiss the picker
        dismiss(animated: true, completion: nil)
        
    }
    
}
