//
//  ProfileVC.swift
//  DonationApp
//
//  Created by Sahil Reddy on 2/5/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit
import Firebase

class ProfileVC: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var profilePic: UIImageView!
    @IBOutlet weak var Name: UILabel!
    @IBOutlet weak var Username: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        var displayUser = "@"
        
        let currUser = Auth.auth().currentUser
        let downloadName = currUser?.displayName
        let names = downloadName?.split(separator: "/")
        
        
        
        displayUser.append(String(names![1]))
    
        Username.text = displayUser
        Name.text = String(names![0])
        
        
        if currUser?.photoURL != nil{
            print("Photo exists")
            DispatchQueue.global().async { [weak self] in
                if let data = try? Data(contentsOf: (currUser?.photoURL)!){
                    if let image = UIImage(data: data){
                        DispatchQueue.main.async {
                            self?.profilePic.image = image
                        }
                    }
                }
            }
   //         URLSession.shared.dataTask(with: (currUser?.photoURL)!){ (data, resp, err) in
     //           if err != nil{
    //                print("error dowloading existing photo")
    //            }
    //            else{
      //              self.profilePic.image = UIImage(data: data!)
        //            print("pic should be displayed")
          //      }
            //    print("this line was executeD")
       //     }
            
        }
        else{
            print("Still need to set profile pic")
        }
        
        print("This code done executed")
        
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    //MARK: Actions
    
    @IBAction func SignOut(_ sender: UIButton) {
        var SOError = false
        
        let firebaseAuth = Auth.auth()
        do {
            try firebaseAuth.signOut()
        } catch let signOutError as NSError {
            print("Error signing out")
            SOError = true
        }
        
        if SOError == false {
            let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let entryViewController = storyboard.instantiateViewController(withIdentifier: "EntryVC")
            self.present(entryViewController, animated: true, completion: nil)
        }
    }
    
    
    @IBAction func selectImageFromPhotoLibrary(_ sender: UITapGestureRecognizer) {
        //UIImagePickercontroller is a view controller that lets a user ipck media from their photo library
    
        
        let imagePickerController = UIImagePickerController()
        
        //Only allow photos to be picked, not taken.
        imagePickerController.sourceType = .photoLibrary
        
        //MAke sure ViewController is notified when the user picks an image.
        imagePickerController.delegate = self
        present(imagePickerController, animated: true, completion: nil)
    }
    
    //MARK: UIImagePickerControllerDelegate
    
    func imagePickerControllerDidCancel(_ _picker: UIImagePickerController){
        //Dismiss the picker if the user canceled
        
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        
        
        //The info dictionary may contain multiple represenations of the image. You want to use the original.
        
        guard let selectedImage = info[.originalImage] as? UIImage else{
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        
        let optimizedImageData = selectedImage.pngData()
        
        setProfilePicture(imageData: optimizedImageData ?? (profilePic.image?.pngData())!)
        

        
        //Dismiss the picker
        dismiss(animated: true, completion: nil)
        
    }
    
    //MARK: Firebase
    
    func setProfilePicture(imageData: Data){
        
        let storageRef = Storage.storage().reference()
        let currentUser = Auth.auth().currentUser
        let profileImageRef = storageRef.child("users").child(currentUser!.uid).child("\(currentUser!.uid)-profileImage.png")
        
        let uploadMetaData = StorageMetadata()
        uploadMetaData.contentType = "image/png"
        
        profileImageRef.putData(imageData, metadata: uploadMetaData) {(uploadedImageMeta, error) in
            
            if error != nil{
                print("Error took place.")
            }
            else{
                //Set photoImageView to display the selected image.
                self.profilePic.image = UIImage(data: imageData)
                let downloadURL = profileImageRef.downloadURL(completion: ){ (url, error) in
                    if error != nil{
                        print("\(error)")
                    }
                    else{
                        let changeReq = currentUser?.createProfileChangeRequest()
                        
                        changeReq?.photoURL = url
                        
                        changeReq?.commitChanges() { error2 in
                            if error2 != nil{
                                print("there was an error setting profile pic")
                            }
                            else{
                                print("Woopty doo")
                            }
                        }
                    }
                }
                
                print("Image uploaded")
            }
            
        }

        
    }
    
}
