//
//  SignUpViewController.swift
//  DonationApp
//
//  Created by Michael Bardos on 2/7/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit
import Firebase

class SignUpViewController: UIViewController, UITextFieldDelegate {
    
    //MARK: Properties
    @IBOutlet weak var eAddrTxtFld: UITextField!
    @IBOutlet weak var ConfirmEAddrTxtFld: UITextField!
    @IBOutlet weak var pWordTxtFld: UITextField!
    @IBOutlet weak var ConfirmPWordTxtFld: UITextField!
    

    override func viewDidLoad() {
        

        eAddrTxtFld.delegate = self
        ConfirmEAddrTxtFld.delegate = self
        pWordTxtFld.delegate = self
        ConfirmPWordTxtFld.delegate = self
        
        super.viewDidLoad()
        
    }
    
    //MARK: UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        //Hide the keyboard
        textField.resignFirstResponder()
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    //MARK: Actions
    
    @IBAction func CreateProfile(_ sender: UIButton) {
        let email: String? = eAddrTxtFld.text
        let emailConfirm: String? = ConfirmEAddrTxtFld.text
        let pword: String? = pWordTxtFld.text
        let pwordConfirm: String? = ConfirmPWordTxtFld.text
        
        var emailKey = true
        var emailCfmKey = true
        var pwordKey = true
        var pwordCfmKey = true
        
        if email?.isEmpty ?? true {
            emailKey = false
            print("Enter a valid email.")
        }
        
        if pword?.isEmpty ?? true {
            pwordKey = false
            print("Enter a valid password.")
        }
        
        if email != emailConfirm{
            emailCfmKey = false
            print("Make sure emails are the same.")
        }
        
        if pword != pwordConfirm{
            pwordCfmKey = false
            print("Make sure passwords are the same.")
        }
        

        
        if emailKey && emailCfmKey && pwordKey && pwordCfmKey{
            
            Auth.auth().createUser(withEmail: email!, password: pword!)
            
            let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homeViewController = storyboard.instantiateViewController(withIdentifier: "CreateProfile2")
            self.present(homeViewController, animated: true, completion: nil)
        }
    }
    

}
