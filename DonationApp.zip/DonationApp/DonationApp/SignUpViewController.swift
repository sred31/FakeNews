//
//  SignUpViewController.swift
//  DonationApp
//
//  Created by Michael Bardos on 2/7/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit
import Firebase

class SignUpViewController: UIViewController, UITextFieldDelegate {
    
    //MARK: Properties
    @IBOutlet weak var eAddrTxtFld: UITextField!
    @IBOutlet weak var ConfirmEAddrTxtFld: UITextField!
    @IBOutlet weak var pWordTxtFld: UITextField!
    @IBOutlet weak var ConfirmPWordTxtFld: UITextField!
    

    override func viewDidLoad() {
        

        eAddrTxtFld.delegate = self
        ConfirmEAddrTxtFld.delegate = self
        pWordTxtFld.delegate = self
        ConfirmPWordTxtFld.delegate = self
        
        super.viewDidLoad()
        
    }
    
    //MARK: UITextFieldDelegate
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        //Hide the keyboard
        textField.resignFirstResponder()
        
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    //MARK: Actions
    
    @IBAction func CreateProfile(_ sender: UIButton) {
        let email: String? = eAddrTxtFld.text
        let emailConfirm: String? = ConfirmEAddrTxtFld.text
        let pword: String? = pWordTxtFld.text
        let pwordConfirm: String? = ConfirmPWordTxtFld.text
        
        if email == nil || emailConfirm == nil || pword == nil || pwordConfirm == nil{
            print("Please fill in the text fields.")
            return
        }
        
        if email != emailConfirm{
            print("Make sure email and confirm email are the same")
            return
        }
        
        if pword != pwordConfirm{
            print("Make sure password and confirm password are the same")
            return
        }
        
        Auth.auth().createUser(withEmail: email!, password: pword!)
        
        if email != nil && emailConfirm != nil && pword != nil && pwordConfirm != nil{
            
            let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homeViewController = storyboard.instantiateViewController(withIdentifier: "TabBar")
            self.present(homeViewController, animated: true, completion: nil)
        }
    }
    

}
