//
//  Profile.swift
//  DonationApp
//
//  Created by Michael Bardos on 2/14/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit

class Profile{
    
    //MARK: Properties
    var email: String
    var password: String
    var username: String
    var profilePic: UIImage
    
    init?(email: String, password: String, username: String, profilePic: UIImage){
        
        if email.isEmpty || password.isEmpty || username.isEmpty {
            return nil
        }
        
        //Initialize stored properties
        
        self.email = email
        self.password = password
        self.username = username
        self.profilePic = profilePic
        
    }
    
}
