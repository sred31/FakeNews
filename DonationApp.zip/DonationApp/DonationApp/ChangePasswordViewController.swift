//
//  ChangePasswordViewController.swift
//  DonationApp
//
//  Created by Michael Bardos on 4/16/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit
import Firebase

class ChangePasswordViewController: UIViewController {
    
    //MARK: Properties
    @IBOutlet weak var NewPassword: UITextField!
    @IBOutlet weak var CfmNewPassword: UITextField!
    @IBOutlet weak var OldPassword: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    //MARK: Actions
    
    @IBAction func ChangePassword(_ sender: UIButton) {
        
        var newPasswordKey = true
        var cNewPasswordKey = true
        var sameKey = false
        var oldPasswordKey = true
        
        if OldPassword.text?.isEmpty ?? true{
            oldPasswordKey = false
        }
        
        if NewPassword.text?.isEmpty ?? true{
            newPasswordKey = false
        }
        
        if CfmNewPassword.text?.isEmpty ?? true{
            cNewPasswordKey = false
        }
        
        if NewPassword.text == CfmNewPassword.text{
            sameKey = true
        }
        
        if oldPasswordKey && newPasswordKey && cNewPasswordKey && sameKey{
            let user = Auth.auth().currentUser
            let credential: AuthCredential = EmailAuthProvider.credential(withEmail: (user?.email)!, password: OldPassword.text!)
            
            
            user?.reauthenticate(with: credential) { error in
                if let error = error {
                    print(error)
                }
                else{
                    user?.updatePassword(to: self.NewPassword.text!) { error2 in
                        if let error2 = error2{
                            print(error2)
                        }
                        else{
                            print("Password changed")
                        }
                    }
                }
            }
            
            let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homeViewController = storyboard.instantiateViewController(withIdentifier: "TabBar")
            self.present(homeViewController, animated: true, completion: nil)
            
            
        }
        
        
    }
    
    
}
