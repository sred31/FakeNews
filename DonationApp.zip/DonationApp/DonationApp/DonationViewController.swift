//
//  DonationViewController.swift
//  DonationApp
//
//  Created by Michael Bardos on 4/20/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit
import Firebase



class DonationViewController: UIViewController {

    @IBOutlet weak var VenmoID: UITextField!
    @IBOutlet weak var DonationAmt: UITextField!
    @IBOutlet weak var DisasterLabel: UILabel!
    
    
    
    var disaster: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        DisasterLabel.text = disaster

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
    //MARK: Actions
    
    @IBAction func Donate(_ sender: UIButton) {
        
        var VenmoKey = true
        var DonationKey = true
        
        if VenmoID.text?.isEmpty ?? true{
            VenmoKey = false
        }
        
        if DonationAmt.text?.isEmpty ?? true{
            DonationKey = false
        }
        
        if VenmoKey && DonationKey {
            
            let user = Auth.auth().currentUser
            let DatabaseRef = Database.database().reference()
            let downloadName = user?.displayName
            
            let names = downloadName?.split(separator: "/")
            
            
            let userKey = DatabaseRef.childByAutoId()
            
            
            
            userKey.child("Name").setValue(String(names![0]))
            
            userKey.child("Venmo").setValue(VenmoID.text)
            
            userKey.child("Disaster").setValue(disaster)
            
            userKey.child("Amount").setValue(DonationAmt.text)
            
            print("Donation received")
            
            let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homeVC = storyboard.instantiateViewController(withIdentifier: "TabBar")
            self.present(homeVC, animated: true, completion: nil)
            
            
            
        }
    }
    
}
