//
//  DisasterExpandedViewController.swift
//  DonationApp
//
//  Created by Michael Bardos on 1/28/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit

class DisasterExpandedViewController: UIViewController, UITextViewDelegate {
    
    //MARK: Properties
    @IBOutlet weak var disasterCharityLabel: UILabel!
    @IBOutlet weak var disasterCharityInfo: UITextView!
    @IBOutlet weak var sourceLabel: UILabel!
    @IBOutlet weak var sourcesLinks: UITextView!
    @IBOutlet weak var disasterImageView: UIImageView!

  
    
    /*
     This value is either passed by 'MealTableViewController' in prepare(for:sender:)
    or constructed as part of adding a new meal
    */
    var disaster: Disaster?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.disasterCharityInfo.delegate = self
        self.sourcesLinks.delegate = self
        
        // Set up views for disaster.
        
        if let disaster = disaster {
            
            disasterCharityInfo.text = disaster.description
            sourcesLinks.text = disaster.URLs
            disasterImageView.image = disaster.photo
        }
        
        
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
        super.prepare(for:segue, sender: sender)
        let text = disaster?.name
        switch(segue.identifier ?? ""){
        case "Donate":
            guard let donaViewController = segue.destination as? DonationViewController else{
                fatalError("Unexpected destination: \(segue.destination)")
            }
            
            donaViewController.disaster = text
            
        default:
            print("Didn't donate")
        }
    }
 

}
