//
//  ChangeEmailViewController.swift
//  DonationApp
//
//  Created by Michael Bardos on 4/16/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit
import Firebase

class ChangeEmailViewController: UIViewController {

    
    //MARK: Properties
    @IBOutlet weak var newEmail: UITextField!
    @IBOutlet weak var cfmNewEmail: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    //MARK: Actions
    @IBAction func ChangeEmail(_ sender: UIButton) {
        var newEmailKey = true
        var cNewEmailKey = true
        var sameKey = false
        
        if newEmail.text?.isEmpty ?? true{
            newEmailKey = false
        }
        
        if cfmNewEmail.text?.isEmpty ?? true{
            cNewEmailKey = false
        }
        
        if cfmNewEmail.text == newEmail.text{
            sameKey = true
        }
        
        if sameKey && cNewEmailKey && newEmailKey {
            let currUser = Auth.auth().currentUser
            
            
            currUser?.updateEmail(to: newEmail.text!) {error in
                if let error = error{
                    print(error)
                }
                else{
                    print("Email changed")
                }
            }
            
            let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homeViewController = storyboard.instantiateViewController(withIdentifier: "TabBar")
            self.present(homeViewController, animated: true, completion: nil)
        }
        
    }
    
    
}
