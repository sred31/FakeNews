//
//  CreateProfile2ViewController.swift
//  DonationApp
//
//  Created by Michael Bardos on 4/1/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit
import Firebase

class CreateProfile2ViewController: UIViewController, UITextFieldDelegate {
    
    //MARK: Properties
    @IBOutlet weak var FirstName: UITextField!
    @IBOutlet weak var LastName: UITextField!
    @IBOutlet weak var Username: UITextField!
    @IBOutlet weak var CfrmUsername: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    //MARK: Actions
    
    @IBAction func AddProfileInfo(_ sender: UIButton) {
        
        var fNameKey = true
        var lNameKey = true
        var uNameKey = true
        var cNameKey = true
        var sameKey = false
        
        if FirstName.text?.isEmpty ?? true {
            fNameKey = false
        }
        
        if LastName.text?.isEmpty ?? true{
            lNameKey = false
        }
        
        if Username.text?.isEmpty ?? true{
            uNameKey = false
        }
        
        if CfrmUsername.text?.isEmpty ?? true{
            cNameKey = false
        }
        
        if Username.text == CfrmUsername.text{
            sameKey = true
        }
        
        if fNameKey && lNameKey && uNameKey && cNameKey && sameKey {
        
            let currUser = Auth.auth().currentUser
            let changeReq = currUser?.createProfileChangeRequest()
            
            //Combine user actual name & profile name to save both on firebase
            var name = ""
            name.append(FirstName.text!)
            name.append(" ")
            name.append(LastName.text!)
            name.append("/")
            name.append(Username.text!)
            
            let result = name.split(separator: "/")
            print(result[0])
            print(result[1])
            
            
            changeReq?.displayName = name
            changeReq?.commitChanges(){ error in
                if error != nil{
                    print("error setting name")
                }
                else{
                    print("Doopty woo")
                }
            }
        
            let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let homeViewController = storyboard.instantiateViewController(withIdentifier: "TabBar")
            self.present(homeViewController, animated: true, completion: nil)
            
        }
    }
    

}
