//
//  DisasterTableViewCell.swift
//  DonationApp
//
//  Created by Michael Bardos on 1/28/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit

class DisasterTableViewCell: UITableViewCell {
    
    //MARK: Properties
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var photoImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    

}
