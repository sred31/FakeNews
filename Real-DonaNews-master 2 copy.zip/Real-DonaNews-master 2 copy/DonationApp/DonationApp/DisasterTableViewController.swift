//
//  DisasterTableViewController.swift
//  DonationApp
//
//  Created by Michael Bardos on 1/30/19.
//  Copyright © 2019 Billion Dollar Company. All rights reserved.
//

import UIKit
import os.log

class DisasterTableViewController: UITableViewController {
    
    //MARK: Properties
    
    var disasters = [Disaster]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Load the sample data.
        loadSampleDisasters()
        
        //Slide Menu options
        NotificationCenter.default.addObserver(self, selector: #selector(showProfile), name: NSNotification.Name("ShowProfile"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(showHelp), name: NSNotification.Name("ShowHelp"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(showSettings), name: NSNotification.Name("ShowSettings"), object: nil)
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    @objc func showProfile(){
        performSegue(withIdentifier: "ShowProfile", sender: nil)
    }
    @objc func showHelp(){
        performSegue(withIdentifier: "ShowHelp", sender: nil)
    }
    @objc func showSettings(){
        performSegue(withIdentifier: "ShowSettings", sender: nil)
    }
    
    @IBAction func MoreTapped(){
        print("TOGGLE SIDE MENU")
        NotificationCenter.default.post(name: NSNotification.Name("ToggleSideMenu"), object: nil)
    }
    

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return disasters.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //Table view cells are reused and should be dequeued using a cell identifier
        let cellIdentifier = "DisasterTableViewCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? DisasterTableViewCell else{
            fatalError("The dequeued cell is not an instance of DisasterTableViewCell")
        }
        
        //Fethches the appropriate meal for the data source layout
        let disaster = disasters[indexPath.row]
        cell.nameLabel.text = disaster.name
        cell.photoImageView.image = disaster.photo
        

        
        // Configure the cell...

        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        switch(segue.identifier ?? "") {
        case "ShowDetail":
            guard let disasterDetailViewController = segue.destination as? DisasterExpandedViewController else{
                fatalError("Unexpected destination: \(segue.destination)")
            }
            guard let selectedDisasterCell = sender as? DisasterTableViewCell else{
                fatalError("Unexpected sender: \(sender)")
            }
            guard let indexPath = tableView.indexPath(for: selectedDisasterCell) else{
                fatalError("The selected cell is not being displayed by the table")
            }
            
            let selectedDisaster = disasters[indexPath.row]
            disasterDetailViewController.disaster = selectedDisaster
            
        default:
            fatalError("Unexpected Segue Identifier; \(segue.identifier)")
        }
        
    }
    

    
    //MARK: Private Methods
    
    private func loadSampleDisasters(){
        
        let photo1 = UIImage(named: "DisasterExample")
        let photo2 = UIImage(named: "DisasterExample2")
        let photo3 = UIImage(named: "DisasterExample3")
        
        guard let disaster1 = Disaster(name: "Earthquake", photo: photo1!, description: "There was an earthquake somewhere. This is how many people were affected. The charity is this one and this is how they donate their money.", URLs: "www.website.com")else{
            fatalError("Unable to instantiate disaster1")
        }
        
        guard let disaster2 = Disaster(name: "Wildfire", photo: photo2!, description: "There was a wildfire somewhere. This is how many people were affected. The charity is this one and this is how they donate their money.", URLs: "www.website.com")else{
            fatalError("Unable to instantiate disaster2")
        }
        
        guard let disaster3 = Disaster(name: "Tsunami", photo: photo3!, description: "There was a tsunami somewhere. This is how many people were affected. The charity is this one and this is how they donate their money.", URLs: "website.com")else{
            fatalError("Unable to instantiate disaster3")
        }
        
        disasters += [disaster1, disaster2, disaster3]
    }
}
